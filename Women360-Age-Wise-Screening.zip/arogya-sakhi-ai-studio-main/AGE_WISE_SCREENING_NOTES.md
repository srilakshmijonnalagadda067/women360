# Women360 — Age-wise 3-minute screening

The supplied Women360 doctor-review questionnaire is the source reference for the screening themes and the 10–19 set. The project now selects a life-stage set before starting the questions:

- 10–19: adolescent/late-teen set based directly on the supplied questionnaire themes.
- 20–29: young-adult adaptation of the same source themes.
- 30–44: adult adaptation of the same source themes.
- 45–50: midlife/menstrual-transition adaptation of the same source themes.
- 60+: older-women adaptation of the same source themes.

The adapted sets are intentionally short for a 3-minute experience. They are screening/awareness questions, not diagnostic criteria. Any persistent or concerning symptom should be reviewed by a qualified healthcare professional.

Reference document included in `docs/`.
