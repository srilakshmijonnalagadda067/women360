export type Language = 'en' | 'te';
export type AppView = 'home' | 'learn' | 'screening' | 'result' | 'wellness';

export interface QuestionOption {
  value: string;
  points: number;
  labelEn: string;
  labelTe: string;
  subEn?: string;
  subTe?: string;
  factorTextEn?: string;
  factorTextTe?: string;
}

export interface ScreeningQuestion {
  id: number;
  badgeEn: string;
  badgeTe: string;
  icon: string;
  titleEn: string;
  titleTe: string;
  descEn: string;
  descTe: string;
  options: QuestionOption[];
}

export interface UserResponses {
  [questionId: number]: {
    value: string;
    points: number;
    optionIndex: number;
  };
}

export type RiskTier = 'lower' | 'moderate' | 'higher';

export interface RiskResult {
  score: number;
  maxScore: number;
  tier: RiskTier;
  tierLabelEn: string;
  tierLabelTe: string;
  descriptionEn: string;
  descriptionTe: string;
  factors: Array<{
    titleEn: string;
    titleTe: string;
    responseEn: string;
    responseTe: string;
    points: number;
  }>;
  ageGroup: string;
}
