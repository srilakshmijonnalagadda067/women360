import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Calendar,
  Sparkles,
  Scissors,
  Activity,
  HeartPulse,
  Moon,
  Users,
  Smile
} from 'lucide-react';
import { Language, UserResponses, QuestionOption } from '../types';
import { AGE_GROUPS, AgeGroup, SCREENING_BY_AGE } from '../data/screeningData';
import { TRANSLATIONS } from '../data/translations';

interface ScreeningScreenProps {
  lang: Language;
  responses: UserResponses;
  onAnswerSelect: (questionId: number, value: string, points: number, optionIndex: number) => void;
  onComplete: () => void;
  onExit: () => void;
  ageGroup: AgeGroup | null;
  onAgeGroupSelect: (ageGroup: AgeGroup) => void;
}

export const ScreeningScreen: React.FC<ScreeningScreenProps> = ({
  lang,
  responses,
  onAnswerSelect,
  onComplete,
  onExit,
  ageGroup,
  onAgeGroupSelect,
}) => {
  const t = TRANSLATIONS[lang];
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [showAccordion, setShowAccordion] = useState<boolean>(false);
  const [showErrorPrompt, setShowErrorPrompt] = useState<boolean>(false);

  const questions = ageGroup ? SCREENING_BY_AGE[ageGroup] : [];
  const totalQuestions = questions.length;
  const currentQuestion = questions[currentStep];
  const currentAnswer = currentQuestion ? responses[currentQuestion.id] : undefined;

  const progressPercent = Math.round(((currentStep + 1) / totalQuestions) * 100);

  const handleSelectOption = (option: QuestionOption, index: number) => {
    onAnswerSelect(currentQuestion.id, option.value, option.points, index);
    setShowErrorPrompt(false);
  };

  const handleNext = () => {
    if (!currentAnswer) {
      setShowErrorPrompt(true);
      return;
    }

    if (currentStep < totalQuestions - 1) {
      setCurrentStep((prev) => prev + 1);
      setShowErrorPrompt(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
      setShowErrorPrompt(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      onExit();
    }
  };

  if (!ageGroup) {
    return (
      <div className="max-w-2xl mx-auto pb-24 pt-6 sm:pt-10">
        <div className="rounded-3xl bg-white border border-[#dcbfc4] p-6 sm:p-8 shadow-sm space-y-6">
          <div className="space-y-2 text-center">
            <span className="text-xs font-bold uppercase tracking-wider text-[#7c113b]">
              {lang === 'en' ? '3-Minute Screening' : '3 నిమిషాల స్క్రీనింగ్'}
            </span>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#151d22]">
              {lang === 'en' ? 'Select your age group' : 'మీ వయస్సు పరిధిని ఎంచుకోండి'}
            </h1>
            <p className="text-sm text-[#564146] leading-relaxed">
              {lang === 'en' ? 'Questions are adapted to the selected life stage using the Women360 questionnaire themes.' : 'Women360 ప్రశ్నావళి అంశాలను ఆధారంగా తీసుకుని మీ వయస్సుకు సరిపోయే ప్రశ్నలు చూపిస్తాము.'}
            </p>
          </div>
          <div className="grid gap-3">
            {AGE_GROUPS.map((group) => (
              <button key={group.value} type="button" onClick={() => onAgeGroupSelect(group.value)} className="w-full p-4 rounded-2xl border border-[#dcbfc4]/80 bg-[#f6faff] hover:border-[#7c113b] hover:bg-[#ffd9e0]/30 text-left transition-all">
                <span className="font-bold text-[#151d22]">{lang === 'en' ? group.labelEn : group.labelTe}</span>
              </button>
            ))}
          </div>
          <div className="rounded-2xl bg-[#fff7f8] border border-[#dcbfc4]/60 p-4 text-xs text-[#564146]">
            {lang === 'en' ? 'Screening and awareness only. This does not diagnose PCOS or any other medical condition.' : 'ఇది అవగాహన మరియు స్క్రీనింగ్ కోసం మాత్రమే. ఇది PCOS లేదా ఇతర వైద్య పరిస్థితిని నిర్ధారించదు.'}
          </div>
          <button type="button" onClick={onExit} className="w-full px-5 py-3 rounded-2xl bg-white border border-[#dcbfc4] text-sm font-bold text-[#564146]">
            {lang === 'en' ? 'Back to Home' : 'హోమ్‌కి వెళ్లండి'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto pb-24 pt-4 sm:pt-6 space-y-6">
      {/* Top Bar: Back & Exit */}
      <div className="flex items-center justify-between">
        <button
          id="btn-screening-back"
          onClick={handlePrev}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-[#dcbfc4] text-xs sm:text-sm font-semibold text-[#564146] hover:text-[#7c113b] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{currentStep === 0 ? (lang === 'en' ? 'Exit to Home' : 'హోమ్‌కి వెళ్లండి') : t.screening.btnBack}</span>
        </button>

        <span className="text-xs font-bold text-[#7c113b] bg-[#ffd9e0] px-3 py-1 rounded-full">
          {currentQuestion.badgeEn ? (lang === 'en' ? currentQuestion.badgeEn : currentQuestion.badgeTe) : 'Assessment'}
        </span>
      </div>

      {/* Progress & Stepper Card */}
      <div className="rounded-3xl bg-white border border-[#dcbfc4]/80 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-xs font-bold uppercase tracking-wider text-[#7c113b]">
              {t.screening.stepperTitle}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-[#151d22]">
              {t.screening.questionProgress} {currentStep + 1} {t.screening.of} {totalQuestions}
            </h2>
          </div>
          <span className="text-sm font-bold text-[#7c113b] bg-[#ffd9e0]/80 px-2.5 py-1 rounded-xl">
            {progressPercent}%
          </span>
        </div>

        {/* Continuous Progress Bar */}
        <div className="w-full bg-[#edf5fc] h-2.5 rounded-full overflow-hidden">
          <div
            className="bg-[#7c113b] h-full rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Step dots indicator */}
        <div className="flex items-center justify-between gap-1 pt-1">
          {questions.map((q, idx) => {
            const isAnswered = Boolean(responses[q.id]);
            const isCurrent = idx === currentStep;

            return (
              <button
                key={q.id}
                id={`step-indicator-${idx + 1}`}
                onClick={() => {
                  // Only allow jumping back to completed questions or current
                  if (idx <= currentStep || isAnswered) {
                    setCurrentStep(idx);
                    setShowErrorPrompt(false);
                  }
                }}
                className={`h-2 flex-1 rounded-full transition-all ${
                  isCurrent
                    ? 'bg-[#7c113b]'
                    : isAnswered
                    ? 'bg-[#9b2c52]/60 hover:bg-[#9b2c52]'
                    : 'bg-[#edf5fc]'
                }`}
                title={`Question ${idx + 1}`}
                aria-label={`Jump to Question ${idx + 1}`}
              />
            );
          })}
        </div>
      </div>

      {/* Question Card */}
      <div className="rounded-3xl bg-white border border-[#dcbfc4] p-6 sm:p-8 shadow-sm space-y-6">
        <div className="space-y-2">
          <h1 className="font-display text-xl sm:text-2xl font-bold text-[#151d22] leading-snug">
            {lang === 'en' ? currentQuestion.titleEn : currentQuestion.titleTe}
          </h1>
          <p className="text-sm text-[#564146] leading-relaxed">
            {lang === 'en' ? currentQuestion.descEn : currentQuestion.descTe}
          </p>
        </div>

        {/* Answer Options */}
        <div className="space-y-3" role="radiogroup" aria-labelledby="question-title">
          {currentQuestion.options.map((option, idx) => {
            const isSelected = currentAnswer?.value === option.value;

            return (
              <button
                key={option.value}
                id={`option-${currentQuestion.id}-${option.value}`}
                type="button"
                role="radio"
                aria-checked={isSelected}
                onClick={() => handleSelectOption(option, idx)}
                className={`w-full text-left p-4 sm:p-5 rounded-2xl border transition-all flex items-start justify-between gap-4 ${
                  isSelected
                    ? 'bg-[#ffd9e0]/40 border-[#7c113b] shadow-xs ring-1 ring-[#7c113b]'
                    : 'bg-[#f6faff] border-[#dcbfc4]/70 hover:bg-[#edf5fc] hover:border-[#7c113b]/40'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-display text-base font-bold ${
                        isSelected ? 'text-[#7c113b]' : 'text-[#151d22]'
                      }`}
                    >
                      {lang === 'en' ? option.labelEn : option.labelTe}
                    </span>
                  </div>
                  {(option.subEn || option.subTe) && (
                    <p className="text-xs sm:text-sm text-[#564146] leading-relaxed">
                      {lang === 'en' ? option.subEn : option.subTe}
                    </p>
                  )}
                </div>

                {/* Selection Indicator */}
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 border transition-all ${
                    isSelected
                      ? 'bg-[#7c113b] border-[#7c113b] text-white'
                      : 'border-[#dcbfc4] bg-white'
                  }`}
                >
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Error prompt if user tries Next without selecting */}
        {showErrorPrompt && !currentAnswer && (
          <div
            id="screening-error-prompt"
            className="flex items-center gap-2 p-3.5 rounded-xl bg-[#fee2e2] text-[#991b1b] text-xs sm:text-sm font-semibold animate-pulse"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{t.screening.selectPrompt}</span>
          </div>
        )}

        {/* Action Controls */}
        <div className="pt-4 flex items-center gap-3 border-t border-[#dcbfc4]/40">
          <button
            id="btn-screening-prev-action"
            type="button"
            onClick={handlePrev}
            className="px-5 py-3.5 rounded-2xl bg-white border border-[#dcbfc4] text-sm font-bold text-[#564146] hover:bg-[#edf5fc] transition-colors"
          >
            {currentStep === 0 ? (lang === 'en' ? 'Cancel' : 'రద్దు') : t.screening.btnBack}
          </button>

          <button
            id="btn-screening-next-action"
            type="button"
            onClick={handleNext}
            className={`flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl text-sm sm:text-base font-bold transition-all shadow-md ${
              currentAnswer
                ? 'bg-[#7c113b] hover:bg-[#630a2d] text-white cursor-pointer transform hover:-translate-y-0.5'
                : 'bg-[#dcbfc4] text-white/90 cursor-not-allowed'
            }`}
          >
            <span>
              {currentStep === totalQuestions - 1
                ? t.screening.btnSubmit
                : t.screening.btnNext}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Accordion: Why we ask these questions (Medical rationale) */}
      <div className="rounded-2xl bg-white border border-[#dcbfc4]/80 overflow-hidden shadow-xs">
        <button
          id="btn-toggle-accordion-rationale"
          type="button"
          onClick={() => setShowAccordion(!showAccordion)}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#edf5fc] transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <HelpCircle className="w-4 h-4 text-[#7c113b]" />
            <span className="text-xs sm:text-sm font-bold text-[#7c113b]">
              {t.screening.accordionTitle}
            </span>
          </div>
          {showAccordion ? (
            <ChevronUp className="w-4 h-4 text-[#7c113b]" />
          ) : (
            <ChevronDown className="w-4 h-4 text-[#7c113b]" />
          )}
        </button>

        {showAccordion && (
          <div className="p-4 pt-0 text-xs sm:text-sm text-[#564146] leading-relaxed border-t border-[#dcbfc4]/30 bg-[#f6faff]">
            <p>{t.screening.accordionText}</p>
          </div>
        )}
      </div>
    </div>
  );
};
