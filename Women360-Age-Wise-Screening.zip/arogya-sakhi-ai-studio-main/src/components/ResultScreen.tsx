import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  FileDown,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Stethoscope,
  PhoneCall,
  Calendar,
  Activity,
  HeartPulse,
  Info,
  ChevronRight
} from 'lucide-react';
import { Language, RiskResult } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { DoctorPrepModal } from './DoctorPrepModal';

interface ResultScreenProps {
  lang: Language;
  result: RiskResult;
  onRetake: () => void;
  onViewWellness: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({
  lang,
  result,
  onRetake,
  onViewWellness,
}) => {
  const t = TRANSLATIONS[lang];
  const [isDoctorModalOpen, setIsDoctorModalOpen] = useState<boolean>(false);

  // Styling based on risk tier
  const tierConfig = {
    lower: {
      color: '#2b6957',
      bgLight: '#b0f0d8/30',
      badgeBg: '#b0f0d8',
      badgeText: '#002118',
      borderColor: '#2b6957',
      icon: CheckCircle2,
    },
    moderate: {
      color: '#c2410c',
      bgLight: '#ffedd5',
      badgeBg: '#fed7aa',
      badgeText: '#7c2d12',
      borderColor: '#ea580c',
      icon: AlertTriangle,
    },
    higher: {
      color: '#7c113b',
      bgLight: '#ffd9e0/40',
      badgeBg: '#ffd9e0',
      badgeText: '#7c113b',
      borderColor: '#7c113b',
      icon: AlertCircle,
    },
  }[result.tier];

  const TierIcon = tierConfig.icon;

  return (
    <div className="max-w-3xl mx-auto pb-24 pt-4 sm:pt-6 space-y-8">
      {/* 1. Mandatory Medical Safety Disclaimer Banner (Prominent Header Notice) */}
      <div
        id="result-disclaimer-banner"
        className="rounded-2xl bg-[#fee2e2]/70 border-2 border-[#dc2626]/30 p-4 sm:p-5 flex items-start gap-3.5 shadow-xs"
      >
        <AlertCircle className="w-5 h-5 text-[#b91c1c] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-xs font-bold uppercase tracking-wider text-[#b91c1c]">
            {lang === 'en' ? 'MANDATORY MEDICAL SAFETY NOTICE' : 'ముఖ్యమైన వైద్య హెచ్చరిక'}
          </p>
          <p className="text-xs sm:text-sm text-[#7f1d1d] font-semibold leading-relaxed">
            {t.result.disclaimer}
          </p>
        </div>
      </div>

      {/* 2. Primary Score & Risk Indicator Card */}
      <div className="rounded-3xl bg-white border border-[#dcbfc4] p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#dcbfc4]/40 pb-6">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#7c113b]">
              {t.result.headerBadge}
            </span>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#151d22]">
              {t.result.title}
            </h1>
          </div>

          {/* Dynamic Risk Tier Badge */}
          <div
            id="result-tier-badge"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl border font-bold text-sm sm:text-base self-start sm:self-auto"
            style={{
              backgroundColor: tierConfig.badgeBg,
              color: tierConfig.badgeText,
              borderColor: tierConfig.borderColor,
            }}
          >
            <TierIcon className="w-5 h-5" />
            <span>{lang === 'en' ? result.tierLabelEn : result.tierLabelTe}</span>
          </div>
        </div>

        {/* Dynamic Score Display (e.g. "Score: 6 / 13") */}
        <div className="rounded-2xl bg-[#f6faff] border border-[#dcbfc4]/60 p-6 flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase text-[#564146] tracking-wider">
              {t.result.scoreLabel}
            </span>
            <div className="flex items-baseline justify-center sm:justify-start gap-2">
              <span className="font-display text-4xl sm:text-5xl font-extrabold text-[#7c113b]">
                {result.score}
              </span>
              <span className="text-base sm:text-lg font-semibold text-[#564146]">
                / {result.maxScore} {lang === 'en' ? 'points' : 'పాయింట్లు'}
              </span>
            </div>
            <p className="text-xs text-[#564146]">
              {t.result.scoreOutOf}
            </p>
          </div>

          <div className="max-w-md text-xs sm:text-sm text-[#564146] leading-relaxed bg-white p-4 rounded-xl border border-[#dcbfc4]/40">
            {lang === 'en' ? result.descriptionEn : result.descriptionTe}
          </div>
        </div>

        {/* 3-State Segmented Risk Indicator Gauge */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#564146]">
            <span>{t.result.scaleTitle}</span>
            <span className="text-[#7c113b]">
              {lang === 'en' ? `Active Tier: ${result.tier.toUpperCase()}` : `ప్రస్తుత స్థాయి: ${result.tierLabelTe}`}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {/* Segment 1: Lower (0-3) */}
            <div
              className={`p-3 rounded-2xl border text-center transition-all ${
                result.tier === 'lower'
                  ? 'bg-[#b0f0d8]/50 border-[#2b6957] ring-2 ring-[#2b6957] shadow-sm'
                  : 'bg-[#edf5fc] border-[#dcbfc4]/40 opacity-70'
              }`}
            >
              <div className="text-[11px] font-bold text-[#2b6957] uppercase">
                {lang === 'en' ? '0 - 3 pts' : '0 - 3 పాయింట్లు'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-[#151d22] mt-0.5">
                {t.result.riskBadge.lower}
              </div>
            </div>

            {/* Segment 2: Moderate (4-7) */}
            <div
              className={`p-3 rounded-2xl border text-center transition-all ${
                result.tier === 'moderate'
                  ? 'bg-[#fed7aa]/50 border-[#ea580c] ring-2 ring-[#ea580c] shadow-sm'
                  : 'bg-[#edf5fc] border-[#dcbfc4]/40 opacity-70'
              }`}
            >
              <div className="text-[11px] font-bold text-[#ea580c] uppercase">
                {lang === 'en' ? '4 - 7 pts' : '4 - 7 పాయింట్లు'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-[#151d22] mt-0.5">
                {t.result.riskBadge.moderate}
              </div>
            </div>

            {/* Segment 3: Higher (8-13) */}
            <div
              className={`p-3 rounded-2xl border text-center transition-all ${
                result.tier === 'higher'
                  ? 'bg-[#ffd9e0]/60 border-[#7c113b] ring-2 ring-[#7c113b] shadow-sm'
                  : 'bg-[#edf5fc] border-[#dcbfc4]/40 opacity-70'
              }`}
            >
              <div className="text-[11px] font-bold text-[#7c113b] uppercase">
                {lang === 'en' ? '8 - 13 pts' : '8 - 13 పాయింట్లు'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-[#151d22] mt-0.5">
                {t.result.riskBadge.higher}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons: View Wellness & Retake */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-4 border-t border-[#dcbfc4]/40">
          <button
            id="btn-result-view-wellness"
            onClick={onViewWellness}
            className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-[#7c113b] hover:bg-[#630a2d] text-white text-sm sm:text-base font-bold shadow-md transition-all"
          >
            <Sparkles className="w-4 h-4 text-[#ffd9e0]" />
            <span>{t.result.viewWellnessBtn}</span>
            <ArrowRight className="w-4 h-4 text-[#ffd9e0]" />
          </button>

          <button
            id="btn-result-doctor-prep"
            onClick={() => setIsDoctorModalOpen(true)}
            className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-white border border-[#7c113b] text-[#7c113b] hover:bg-[#ffd9e0]/40 text-sm font-bold shadow-xs transition-colors"
          >
            <FileDown className="w-4 h-4" />
            <span>{t.result.doctorPrepBtn}</span>
          </button>

          <button
            id="btn-result-retake"
            onClick={onRetake}
            className="inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl bg-[#edf5fc] hover:bg-[#dcbfc4]/30 text-[#564146] text-sm font-bold transition-colors"
            title={t.result.retakeBtn}
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.result.retakeBtn}</span>
          </button>
        </div>
      </div>

      {/* 3. Key Factors from Your Assessment */}
      <div className="rounded-3xl bg-white border border-[#dcbfc4]/80 p-6 sm:p-8 shadow-xs space-y-4">
        <div className="space-y-1">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#151d22]">
            {t.result.factorsTitle}
          </h2>
          <p className="text-xs sm:text-sm text-[#564146]">
            {t.result.factorsSubtitle}
          </p>
        </div>

        <div className="space-y-2.5">
          {result.factors.map((factor, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between gap-4 p-3.5 sm:p-4 rounded-2xl bg-[#f6faff] border border-[#dcbfc4]/50"
            >
              <div className="space-y-0.5">
                <p className="text-xs sm:text-sm font-bold text-[#151d22]">
                  {lang === 'en' ? factor.titleEn : factor.titleTe}
                </p>
                <p className="text-xs text-[#564146]">
                  {lang === 'en' ? `Logged Response: ${factor.responseEn}` : `ఎంపిక: ${factor.responseTe}`}
                </p>
              </div>

              <div className="shrink-0">
                <span
                  className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                    factor.points > 0
                      ? 'bg-[#ffd9e0] text-[#7c113b]'
                      : 'bg-[#edf5fc] text-[#564146]'
                  }`}
                >
                  +{factor.points} {lang === 'en' ? 'pts' : 'పాయింట్లు'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. What Your Result Means & Next Steps */}
      <div className="rounded-3xl bg-white border border-[#dcbfc4]/80 p-6 sm:p-8 shadow-xs space-y-6">
        <h2 className="font-display text-xl sm:text-2xl font-bold text-[#151d22]">
          {t.result.nextStepsTitle}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {t.result.nextStepsList.map((stepItem, idx) => (
            <div
              key={idx}
              className="rounded-2xl bg-[#f6faff] border border-[#dcbfc4]/60 p-5 space-y-2.5 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <span className="w-8 h-8 rounded-xl bg-[#7c113b] text-white flex items-center justify-center font-display font-bold text-sm">
                  {stepItem.step}
                </span>
                <h3 className="font-display text-base font-bold text-[#151d22]">
                  {stepItem.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#564146] leading-relaxed">
                  {stepItem.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Free Health Advisory Support Helpline Card */}
      <div className="rounded-2xl bg-gradient-to-r from-[#2b6957]/10 via-[#edf5fc] to-white border border-[#2b6957]/30 p-5 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-[#2b6957] text-white flex items-center justify-center shrink-0 shadow-xs">
            <PhoneCall className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#151d22]">
              {t.result.helplineCardTitle}
            </h3>
            <p className="text-xs text-[#564146]">
              {t.result.helpline104Desc}
            </p>
          </div>
        </div>

        <a
          id="btn-call-104-result"
          href="tel:104"
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#2b6957] text-white text-xs sm:text-sm font-bold shadow-xs hover:bg-[#1f4e40] transition-colors self-stretch sm:self-auto"
        >
          <PhoneCall className="w-4 h-4" />
          <span>{lang === 'en' ? 'Call 104 Toll-Free' : '104 కి కాల్ చేయండి'}</span>
        </a>
      </div>

      {/* Doctor Visit Prep Modal Dialog */}
      <DoctorPrepModal
        lang={lang}
        isOpen={isDoctorModalOpen}
        onClose={() => setIsDoctorModalOpen(false)}
        userScore={result.score}
        userTier={lang === 'en' ? result.tierLabelEn : result.tierLabelTe}
      />
    </div>
  );
};
