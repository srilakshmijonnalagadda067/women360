/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeScreen } from './components/HomeScreen';
import { ScreeningScreen } from './components/ScreeningScreen';
import { ResultScreen } from './components/ResultScreen';
import { WellnessScreen } from './components/WellnessScreen';
import { LearnScreen } from './components/LearnScreen';
import { Language, AppView, UserResponses, RiskResult, RiskTier } from './types';
import { SCREENING_BY_AGE, AgeGroup } from './data/screeningData';
import { TRANSLATIONS } from './data/translations';
import { HeartPulse, PhoneCall, ShieldCheck } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [view, setView] = useState<AppView>('home');
  const [responses, setResponses] = useState<UserResponses>({});
  const [result, setResult] = useState<RiskResult | null>(null);
  const [ageGroup, setAgeGroup] = useState<AgeGroup | null>(null);

  const t = TRANSLATIONS[lang];

  // Scroll to top upon view change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [view]);

  // Handle option selection in screening
  const handleAnswerSelect = (
    questionId: number,
    value: string,
    points: number,
    optionIndex: number
  ) => {
    setResponses((prev) => ({
      ...prev,
      [questionId]: { value, points, optionIndex },
    }));
  };

  // Calculate score and evaluate risk
  const calculateResult = (): RiskResult => {
    let totalScore = 0;
    const factors: RiskResult['factors'] = [];

    const questions = ageGroup ? SCREENING_BY_AGE[ageGroup] : [];
    questions.forEach((q) => {
      const resp = responses[q.id];
      if (resp) {
        totalScore += resp.points;
        const opt = q.options[resp.optionIndex] || q.options.find((o) => o.value === resp.value);
        factors.push({
          titleEn: q.titleEn,
          titleTe: q.titleTe,
          responseEn: opt ? `${opt.labelEn} (${opt.subEn || ''})` : resp.value,
          responseTe: opt ? `${opt.labelTe} (${opt.subTe || ''})` : resp.value,
          points: resp.points,
        });
      }
    });

    let tier: RiskTier = 'lower';
    let tierLabelEn = t.result.riskBadge.lower;
    let tierLabelTe = TRANSLATIONS.te.result.riskBadge.lower;
    let descEn = t.result.tierExpl.lower;
    let descTe = TRANSLATIONS.te.result.tierExpl.lower;

    const maxScore = questions.reduce((sum, q) => sum + Math.max(...q.options.map((o) => o.points)), 0);
    const moderateThreshold = Math.max(2, Math.ceil(maxScore * 0.35));
    const higherThreshold = Math.max(moderateThreshold + 1, Math.ceil(maxScore * 0.65));

    if (totalScore >= higherThreshold) {
      tier = 'higher';
      tierLabelEn = t.result.riskBadge.higher;
      tierLabelTe = TRANSLATIONS.te.result.riskBadge.higher;
      descEn = t.result.tierExpl.higher;
      descTe = TRANSLATIONS.te.result.tierExpl.higher;
    } else if (totalScore >= moderateThreshold) {
      tier = 'moderate';
      tierLabelEn = t.result.riskBadge.moderate;
      tierLabelTe = TRANSLATIONS.te.result.riskBadge.moderate;
      descEn = t.result.tierExpl.moderate;
      descTe = TRANSLATIONS.te.result.tierExpl.moderate;
    }

    return {
      score: totalScore,
      maxScore,
      ageGroup: ageGroup || 'Not selected',
      tier,
      tierLabelEn,
      tierLabelTe,
      descriptionEn: descEn,
      descriptionTe: descTe,
      factors,
    };
  };

  const handleScreeningComplete = () => {
    const computed = calculateResult();
    setResult(computed);
    setView('result');
  };

  // Retake screening clears session answers and starts again
  const handleRetakeScreening = () => {
    setResponses({});
    setResult(null);
    setAgeGroup(null);
    setView('screening');
  };

  const handleNavigate = (newView: AppView) => {
    // If navigating to screening and user already completed it, show result or allow re-screening
    setView(newView);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f6faff] text-[#151d22]">
      {/* Top Fixed / Sticky Navigation Bar */}
      <Header
        lang={lang}
        onLanguageChange={setLang}
        currentView={view}
        onNavigate={handleNavigate}
      />

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        {view === 'home' && (
          <HomeScreen
            lang={lang}
            onNavigate={handleNavigate}
            hasPreviousResult={Boolean(result)}
          />
        )}

        {view === 'learn' && (
          <LearnScreen
            lang={lang}
            onStartScreening={() => setView('screening')}
          />
        )}

        {view === 'screening' && (
          <ScreeningScreen
            lang={lang}
            responses={responses}
            onAnswerSelect={handleAnswerSelect}
            onComplete={handleScreeningComplete}
            onExit={() => setView('home')}
            ageGroup={ageGroup}
            onAgeGroupSelect={(group) => { setAgeGroup(group); setResponses({}); setResult(null); }}
          />
        )}

        {view === 'result' && result && (
          <ResultScreen
            lang={lang}
            result={result}
            onRetake={handleRetakeScreening}
            onViewWellness={() => setView('wellness')}
          />
        )}

        {view === 'wellness' && (
          <WellnessScreen
            lang={lang}
            onNavigateScreening={() => setView('screening')}
            userResult={result}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-[#dcbfc4]/80 py-8 pb-20 md:pb-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-[#dcbfc4]/40 pb-6 text-center md:text-left">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#7c113b] text-white flex items-center justify-center">
                <HeartPulse className="w-5 h-5 text-[#ffd9e0]" />
              </div>
              <div>
                <span className="font-display font-bold text-base text-[#7c113b]">
                  {lang === 'en' ? 'Women360' : 'ఆరోగ్య సఖి'}
                </span>
                <p className="text-xs text-[#564146]">
                  {t.appSubtitle}
                </p>
              </div>
            </div>

            {/* Helpline quick dial buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <a
                id="footer-call-104"
                href="tel:104"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#b0f0d8]/60 text-[#2b6957] hover:bg-[#b0f0d8] text-xs font-bold transition-colors border border-[#2b6957]/30"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>104 {lang === 'en' ? "Health Helpline" : 'వైద్య సహాయవాణి'}</span>
              </a>

              <a
                id="footer-call-1091"
                href="tel:1091"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#ffd9e0]/60 text-[#7c113b] hover:bg-[#ffd9e0] text-xs font-bold transition-colors border border-[#dcbfc4]"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>1091 {lang === 'en' ? "Women Safety" : 'మహిళా రక్షణ'}</span>
              </a>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#564146] text-center sm:text-left">
            <p>{t.footer.copyright}</p>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setView('home')}
                className="hover:text-[#7c113b] transition-colors"
              >
                {t.nav.home}
              </button>
              <button
                onClick={() => setView('learn')}
                className="hover:text-[#7c113b] transition-colors"
              >
                {t.nav.learn}
              </button>
              <button
                onClick={() => setView('screening')}
                className="hover:text-[#7c113b] transition-colors"
              >
                {t.nav.risk}
              </button>
              <button
                onClick={() => setView('wellness')}
                className="hover:text-[#7c113b] transition-colors"
              >
                {t.nav.wellness}
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        lang={lang}
        currentView={view}
        onNavigate={handleNavigate}
      />
    </div>
  );
}

